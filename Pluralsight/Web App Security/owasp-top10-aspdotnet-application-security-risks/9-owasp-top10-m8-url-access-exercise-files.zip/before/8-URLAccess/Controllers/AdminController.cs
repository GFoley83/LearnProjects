﻿using System.Web.Mvc;

namespace _8_URLAccess.Controllers
{
  public class AdminController : Controller
  {
    public ActionResult Index()
    {
      return View();
    }
  }
}
