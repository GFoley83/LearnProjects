﻿using System;

namespace _7_CryptoStorage.Account
{
  public partial class ChangePasswordSuccess : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {

    }
  }
}
