﻿using System;

namespace _7_CryptoStorage
{
  public partial class SiteMaster : System.Web.UI.MasterPage
  {
    protected void Page_Load(object sender, EventArgs e)
    {

    }
  }
}
