﻿using System;

namespace _7_CryptoStorage
{
  public partial class About : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {

    }
  }
}
