﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _3_BrokenAuth.Models
{
  public class SampleLoginModel
  {
    public string Username { get; set; }
    public string Password { get; set; }
  }
}