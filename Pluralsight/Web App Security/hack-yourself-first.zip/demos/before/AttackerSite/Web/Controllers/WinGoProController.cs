﻿using System.Web.Mvc;

namespace Web.Controllers
{
  public class WinGoProController : Controller
  {
    //
    // GET: /WinGoPro/
    public ActionResult Index()
    {
      return View();
    }
  }
}
