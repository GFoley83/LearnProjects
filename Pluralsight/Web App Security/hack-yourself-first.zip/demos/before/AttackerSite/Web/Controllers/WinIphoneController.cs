﻿using System.Web.Mvc;

namespace Web.Controllers
{
  public class WinIphoneController : Controller
  {
    //
    // GET: /WinIphone/
    public ActionResult Index()
    {
      return View();
    }
  }
}
